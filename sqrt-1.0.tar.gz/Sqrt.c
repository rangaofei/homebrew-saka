#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Configure.h"

#ifdef USE_MYSQRT
#include "MathFunctions.h"
#endif
int main (int argc, char *argv[])
{
    if (argc < 2)
    {
        fprintf(stdout,"%s Version %d.%d\n",argv[0],
        VERSION_MAJOR,VERSION_MINOR);
        return 1;
    }
    double inputValue = atof(argv[1]);
#ifdef USE_MYSQRT
    double outputValue = mysqrt(inputValue);
#else
    double outputValue=sqrt(inputValue);
#endif
    fprintf(stdout,"The square root of %g is %g\n",
            inputValue, outputValue);
    return 0;
}